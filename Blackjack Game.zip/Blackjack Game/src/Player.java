import java.util.ArrayList;
import java.util.ArrayList;
public class Player {
    private ArrayList<Card> hand;

    public Player(){
        hand = new ArrayList<>();
    }

    public void addCard(Card card){
        hand.add(card);
    }

    public int findScore(){
        int score = 0;
        int numAces = 0;

        for(Card card: hand){
            score += card.getValue();
            if (card.getValue() == 11) {
                numAces++;
            }
        }

        while(score > 21 && numAces > 0){
            score = score - 10;
            numAces--;
        }

        return score;
    }

    public boolean playerBusted(){
        return findScore() > 21;
    }

    public ArrayList<Card> getHand(){
        return hand;
    }
}
