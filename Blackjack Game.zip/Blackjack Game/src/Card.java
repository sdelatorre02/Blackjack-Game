public class Card {
    private String suit;
    private String cardNum;
    private int value;

    public Card(String suit, String rank, int value) {
        this.suit = suit;
        this.cardNum = rank;
        this.value = value;
    }

    public int getValue() {
        return value;
    }

    @Override
    public String toString() {

        return cardNum + " of " + suit;
    }
}
