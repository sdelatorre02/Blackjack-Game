import java.util.InputMismatchException;
import java.util.Scanner;

public class BlackjackGame {
    private Deck deck;
    private Player player;
    private Player dealer;
    private int numberOfDecks;

    public BlackjackGame(int numberOfDecks){
        this.numberOfDecks = numberOfDecks;
        deck = new Deck(numberOfDecks);
        deck.shuffle();
        player = new Player();
        dealer = new Player();
    }

    public void startGame(int buyIn, int bet) throws InterruptedException {
        player.addCard(deck.deal());
        dealer.addCard(deck.deal());
        player.addCard(deck.deal());
        dealer.addCard(deck.deal());

        System.out.println("Your hand: " + player.getHand());
        System.out.println("Dealer's hand: " + dealer.getHand().get(0) + " and [unknown]");

        Scanner input = new Scanner(System.in);
        while (true) {
            System.out.println("Your score: " + player.findScore());
            System.out.println("Would you like to hit, stand, or double down? [h/s/d]");
            String move = input.nextLine();
            if(player.findScore() == 21){
                System.out.println("You got Blackjack!");
                break;
            }
            if (move.equals("h")) {
                player.addCard(deck.deal());
                System.out.println("Your hand: " + player.getHand());
                System.out.println("Dealer's hand: " + dealer.getHand().get(0) + " and [unknown]");
                if (player.playerBusted()) {
                    System.out.println("You busted! You had a " + player.findScore());
                    break;
                }
            } else if(move.equals("d")){
                if(bet > buyIn)
                {
                    System.out.println("Insufficient funds, hit instead");
                    player.addCard(deck.deal());
                    System.out.println("Your hand: " + player.getHand());

                    if (player.playerBusted()) {
                        System.out.println("You busted! You had a " + player.findScore());
                        break;
                    }
                    break;
                } else {
                    buyIn = buyIn - bet;
                    bet = bet * 2;
                    player.addCard(deck.deal());
                    System.out.println("Your hand: " + player.getHand());

                    if (player.playerBusted()) {
                        System.out.println("You busted! You had a " + player.findScore());
                        break;
                    }
                    break;
                }
            } else if (move.equals("s")) {
                break;
            } else{
                System.out.println("Invalid option, try again.");
            }
        }

        System.out.println("Dealer's hand: " + dealer.getHand());
        while (dealer.findScore() < 17 && player.findScore() <= 21) {
            dealer.addCard(deck.deal());
            Thread.sleep(1000);
            System.out.println("Dealer's hand: " + dealer.getHand());

            if (dealer.playerBusted()) {
                System.out.println("The dealer busted!");
            }
        }

        int playerScore = player.findScore();
        int dealerScore = dealer.findScore();

        Thread.sleep(1000);
        System.out.print("\n");
        System.out.println("You had a final score of :" + playerScore);
        System.out.println("The dealer had a final score of :" + dealerScore + "\n");

        if (playerScore > dealerScore && playerScore <= 21 || dealerScore > 21) {
            System.out.println("Congrats you won!\n");
            buyIn = buyIn + (bet * 2);
        } else if (playerScore < dealerScore && dealerScore <= 21 || playerScore > 21) {
            System.out.println("Dealer wins!\n");
        } else {
            System.out.println("You and the dealer pushed!\n");
            buyIn = buyIn + bet;
        }
        //Lists the players current chip count after each hand
        System.out.println("Your chip balance: " + buyIn);

        //Checks to see if player has chips remaining. If so, asks if they want to continue playing otherwise the game is ended.
        if (buyIn == 0) {
            System.out.println("You're out of chips! Better luck next time...");
        } else {
            while(true) {
                System.out.println("Would you like to play again? [y/n]");
                String again = input.nextLine();
                if (again.equals("y")) {
                    System.out.println("How much would you like to bet on this hand? ");
                    bet = input.nextInt();
                    while (bet > buyIn) {
                        System.out.println("Insufficient Funds. Try again ");
                        bet = input.nextInt();
                    }
                    buyIn = buyIn - bet;
                    resetGame();
                    startGame(buyIn, bet);
                    break;
                } else if (again.equals("n")) {
                    System.out.println("Cashing you out for $" + buyIn + "...\n Thanks for playing!");
                    return;
                } else {
                    System.out.println("Invalid option, try again.");
                }
            }
        }
    }

    //Resets the game if the player wants to continue playing
    public void resetGame(){
        deck = new Deck(numberOfDecks);
        deck.shuffle();
        player.getHand().clear();
        dealer.getHand().clear();
    }
    public static void main(String[] args) throws InterruptedException {
        Scanner input = new Scanner(System.in);
        boolean valid = false;
        boolean valid2 = false;
        boolean valid3 = false;
        int numberOfDecks = 0;
        int buyIn = 0;
        int bet = 0;

        while(!valid) {
            System.out.println("Welcome to Blackjack! How many decks do you want to play?");
            try {
                numberOfDecks = input.nextInt();
                valid = true;
            } catch(InputMismatchException e){
                System.out.println("Invalid number of decks. Enter a integer value");
                input.nextLine();
            }
        }
        BlackjackGame game = new BlackjackGame(numberOfDecks);
        while(!valid2) {
            System.out.println("How much would you like to buy in for?");
            try {
                buyIn = input.nextInt();
                valid2 = true;
            } catch(InputMismatchException e){
                System.out.println("Invalid buy in. Enter a integer value");
                input.nextLine();
            }
        }
        while(!valid3) {
            System.out.println("How much would you like to bet on this hand? ");
            try {
                bet = input.nextInt();
                valid3 = true;
            } catch(InputMismatchException e){
                System.out.println("Invalid bet. Enter a integer value");
                input.nextLine();
            }
        }
        while(bet > buyIn){
            System.out.println("Insufficient Funds. Try again ");
            bet = input.nextInt();
        }
        buyIn = buyIn - bet;
        game.startGame(buyIn, bet);
    }
}

